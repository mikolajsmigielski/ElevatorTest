﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorScript : MonoBehaviour
{
    public Transform ElevatorTransform;
    public Animator DoorAnimator;
    public bool OpenDoor = false;
    bool PlayerInDoor = false;
    void Update()
    {
        if (PlayerInDoor == true)//If Player is in door, keep door open
        {
            OpenDoor = true;
        }
        DoorAnimator.SetBool("IsOpen", OpenDoor);// Set IsOpen in Animator in every frame
        
    }
    private void OnTriggerEnter(Collider Player)//On collision, check if it is player. If is, set PlayerInDoor to true
    {
        if (Player.gameObject.CompareTag("Player"))
        {
            PlayerInDoor = true;
        }
    }
    private void OnTriggerExit(Collider Player)//If Player exit colision, then set PlayerInDoor on false
    {
        PlayerInDoor = false;
    }
}
