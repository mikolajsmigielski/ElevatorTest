﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovment : MonoBehaviour
{
    
    public float PlayerSpeed = 10f;
    void Update()
    {
        float x = Input.GetAxis("Horizontal");//Get value of "Horizontal" Axis, and set to it value x
        float z = Input.GetAxis("Vertical");//Get value of "Horizontal" Axis, and set to it value z

        transform.Translate(Vector3.right * x * PlayerSpeed * Time.deltaTime);//Translate player position base on PlayerSpeed value, Time that pass between the frame, and x 
        transform.Translate(Vector3.forward * z * PlayerSpeed * Time.deltaTime);//Translate player position base on PlayerSpeed value, Time that pass between the frame, and z

        if (Input.GetKeyDown(KeyCode.Escape))//On escape exit game
        {
            Application.Quit();
        }
    }
}
