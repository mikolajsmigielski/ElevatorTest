﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeElevatorAParent : MonoBehaviour
{
    public bool IsChild = false;
    private void OnTriggerEnter(Collider Player)//On collision, check if it is player. If is, make a Player child of Elevator and set IsChild to true
    {
        if (Player.gameObject.CompareTag("Player"))    
        {
            Player.transform.parent = transform;
            IsChild = true;
        }
    }
    private void OnTriggerExit(Collider Player)//If player exit collision, perform the reverse operation
    {
        if (Player.gameObject.CompareTag("Player"))
        {
            Player.transform.parent = null;
            IsChild = false;
        }
    }
}
