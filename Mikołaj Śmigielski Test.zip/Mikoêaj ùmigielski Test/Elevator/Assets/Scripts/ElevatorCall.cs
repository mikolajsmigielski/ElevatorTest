﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElevatorCall : MonoBehaviour
{
    
    public Transform Elevator;
    public MakeElevatorAParent ParentElevator;
    bool ElevatorIsGoing = false;
    public float DestinationPosition;

    public AudioSource ASSelect;
    public AudioSource ASStart;
    public AudioSource ASStop;
    public AudioSource ASIsGoing;

    public DoorScript DS;
    
    bool IsInPlace=false;
    bool WasAlreadyHere = false;
    bool StartCountingToClose = false;
    bool StartCountingToGo = false;

    float WaitTimeToClose = 15;
    float WaitTimeToGo = 2;
    
    
    void Update()
    {
        if (DestinationPosition != Elevator.transform.position.y && ElevatorIsGoing == true)//If Destination position is diffrent from Elevator position and Elevator can move, then
        {
            if (ASIsGoing.isPlaying == false)//If music don't play, play start sound and music
            {
                ASStart.Play();
                ASIsGoing.Play();
            }
            if (DestinationPosition > Elevator.transform.position.y)//If Destination position is higher then elevator position then move elevator up
            {
                Elevator.transform.Translate(Vector3.up * Time.deltaTime * 5);
            }
            if (DestinationPosition < Elevator.transform.position.y)//If Destination position is lower then elevator position then move elevator down
            {
                Elevator.transform.Translate(Vector3.down * Time.deltaTime * 5);
            }
        }
        if (DestinationPosition <= Elevator.transform.position.y + 0.02f && DestinationPosition >= Elevator.transform.position.y - 0.02f && ASIsGoing.isPlaying == true)//if elevator is close enought to destination position and music is plaing, then
        {
            ASIsGoing.Stop();//stop playing music
            ASStop.Play();//plasy stop sound
            ElevatorIsGoing = false;// Set that elevator can't move
            IsInPlace = true;// set that elevator is in place
            WasAlreadyHere = false;//set that elevator just got here
        }
        if (IsInPlace == true && WasAlreadyHere == false)// if elevator is in place but just got here then 
        {  
            DS.OpenDoor = true;// open door
            IsInPlace = false;// set that elevator is not just got here
            WasAlreadyHere = true;// set, that elevator was already here
        }
        
        if (DS.OpenDoor == true)//if door is open, start counting time to close
        {
            StartCountingToClose = true;
        }
        if (WaitTimeToClose > 0 && StartCountingToClose == true)//If counting started, but not yet reach 0, then keep subtracting
        {
            WaitTimeToClose -= Time.deltaTime;
        }
        if (WaitTimeToClose < 0)//If counting reach 0, then reset wait time, close door and set, that it is time to begin counting to false
        {
            WaitTimeToClose = 15;
            DS.OpenDoor = false;
            StartCountingToClose = false;
        }
        if(WaitTimeToGo > 0 && StartCountingToGo == true)//If counting started, but not yet reach 0, then keep subtracting
        {
            WaitTimeToGo -= Time.deltaTime;
        }
        if (WaitTimeToGo < 0)//If counting reach 0, then reset wait time, set that elevator can go, and set, that it is time to begin counting to false
        {
            WaitTimeToGo = 2;
            ElevatorIsGoing = true;
            StartCountingToGo = false;
        }
    }

    private void OnMouseDown()//when mouse button down
    {
        ASSelect.Play();// play select sound
        if (ElevatorIsGoing == false )//if it set that elevator can't go then
        {
            StartCountingToGo = true;// set that program can begin counting
            if (DS.OpenDoor == true)// if door is open then close it
            {
                DS.OpenDoor = false;
            }
            else if (DS.OpenDoor == false && ParentElevator.IsChild == false && WasAlreadyHere == true)// if door is closed, Player is not in elevator and elevator was here before then
            {
                DS.OpenDoor = true;//open door
            }
        }
    }
}
