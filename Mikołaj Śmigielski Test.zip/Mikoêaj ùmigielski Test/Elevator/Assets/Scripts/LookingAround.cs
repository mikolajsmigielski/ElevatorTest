﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookingAround : MonoBehaviour
{
    public float MouseSensitivity = 100f;
    public Transform PlayerTransform;
    float XRotation = 0f;
    

    
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;//Lock mouse cursor on the middle of the screen
    }

    
    void Update()
    {
        float MouseX = Input.GetAxis("Mouse X") * MouseSensitivity * Time.deltaTime;// get a value to rotate base on MouseSensitivity, Time that pass between the frame and input axis
        float MouseY = Input.GetAxis("Mouse Y") * MouseSensitivity * Time.deltaTime;// get a value to rotate base on MouseSensitivity, Time that pass between the frame and input axis
        XRotation -= MouseY;//subtract the calculated value
        XRotation = Mathf.Clamp(XRotation, -90f, 90f);//set the rotation angle limits to 90 an -90 degrees
        transform.localRotation = Quaternion.Euler(XRotation, 0f, 0f);//Perform Euler actions and rotate camra


        PlayerTransform.Rotate(Vector3.up * MouseX);// Rotate Player
        
    }
    
}
